import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:sentry_flutter/sentry_flutter.dart';

import 'report_service.dart';

/// Service responsible for submitting scan reports to the remote API
/// after every scan event (Burgenland or Ticket).
///
/// Uses Dio with retry logic and timeout handling.
/// Follows the Repository pattern – no direct API calls from UI.
class ReportApiService {
  static final ReportApiService _instance = ReportApiService._internal();
  factory ReportApiService() => _instance;
  ReportApiService._internal();

  static const String _baseUrl = 'http://168.119.21.197:8080';
  static const String _submitReportPath = '/api/submit_report';
  static const int _maxRetries = 3;
  static const Duration _timeout = Duration(seconds: 10);

  late final Dio _dio = _createDio();

  // Cached device info to avoid repeated async lookups
  String? _cachedDeviceId;
  String? _cachedDeviceName;
  String? _cachedAppVersion;

  Dio _createDio() {
    final dio = Dio(
      BaseOptions(
        baseUrl: _baseUrl,
        connectTimeout: _timeout,
        receiveTimeout: _timeout,
        sendTimeout: _timeout,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      ),
    );

    // Add logging interceptor in debug mode
    if (kDebugMode) {
      dio.interceptors.add(
        LogInterceptor(
          requestBody: true,
          responseBody: true,
          logPrint: (obj) => debugPrint('[DIO] $obj'),
        ),
      );
    }

    return dio;
  }

  /// Initialize device info cache at app start for faster submissions.
  Future<void> init() async {
    await _loadDeviceInfo();
  }

  Future<void> _loadDeviceInfo() async {
    try {
      final DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();

      if (Platform.isAndroid) {
        final androidInfo = await deviceInfo.androidInfo;
        _cachedDeviceId = androidInfo.id;
        _cachedDeviceName = '${androidInfo.brand} ${androidInfo.model}';
      } else if (Platform.isIOS) {
        final iosInfo = await deviceInfo.iosInfo;
        _cachedDeviceId = iosInfo.identifierForVendor ?? iosInfo.name;
        _cachedDeviceName = iosInfo.name;
      }

      final packageInfo = await PackageInfo.fromPlatform();
      _cachedAppVersion = packageInfo.version;
    } catch (e) {
      debugPrint('Error loading device info for API: $e');
    }
  }

  /// Submits the current day's scan report to the remote API.
  ///
  /// Called after every scan event. Gathers fresh counts from
  /// [ReportService] and sends them alongside device metadata.
  ///
  /// Uses retry logic with exponential backoff.
  Future<bool> submitReport() async {
    try {
      // Ensure device info is loaded
      if (_cachedDeviceId == null) {
        await _loadDeviceInfo();
      }

      // Get current day's cumulative report data
      final reportData = await ReportService().getReportData(DateTime.now());

      final payload = {
        'device_id': _cachedDeviceId ?? 'unknown_device',
        'device_name': _cachedDeviceName ?? 'Unknown Device',
        'app_version': _cachedAppVersion ?? '1.0.0',
        'burgenland_success': reportData['burgenlandCount'] ?? 0,
        'burgenland_fail': reportData['burgenlandFailCount'] ?? 0,
        'ticket_success': reportData['ticketCount'] ?? 0,
        'ticket_invalid': reportData['ticketInvalidCount'] ?? 0,
        'ticket_fail': reportData['ticketFailCount'] ?? 0,
      };

      debugPrint('📤 Submitting scan report to API: $payload');

      // Retry with exponential backoff
      for (int attempt = 1; attempt <= _maxRetries; attempt++) {
        try {
          final response = await _dio.post(
            _submitReportPath,
            data: payload,
          );

          if (response.statusCode == 200 || response.statusCode == 201) {
            debugPrint('✅ Report submitted successfully (attempt $attempt)');
            return true;
          } else {
            debugPrint(
              '⚠️ Unexpected status code: ${response.statusCode} (attempt $attempt)',
            );
          }
        } on DioException catch (e) {
          debugPrint(
            '❌ API call failed (attempt $attempt/$_maxRetries): ${e.message}',
          );

          if (attempt < _maxRetries) {
            // Exponential backoff: 1s, 2s, 4s
            final delay = Duration(seconds: 1 << (attempt - 1));
            debugPrint('⏳ Retrying in ${delay.inSeconds}s...');
            await Future.delayed(delay);
          } else {
            // Final attempt failed – log to Sentry
            try {
              Sentry.captureException(
                e,
                stackTrace: e.stackTrace,
                withScope: (scope) {
                  scope.setTag('api_endpoint', _submitReportPath);
                  scope.setContexts('request_payload', payload);
                },
              );
            } catch (_) {}
          }
        }
      }

      return false;
    } catch (e, stackTrace) {
      debugPrint('❌ Error submitting report: $e');
      try {
        Sentry.captureException(e, stackTrace: stackTrace);
      } catch (_) {}
      return false;
    }
  }
}
